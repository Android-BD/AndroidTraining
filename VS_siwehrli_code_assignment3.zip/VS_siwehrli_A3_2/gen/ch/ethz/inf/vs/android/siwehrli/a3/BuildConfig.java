/** Automatically generated file. DO NOT MODIFY */
package ch.ethz.inf.vs.android.siwehrli.a3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}